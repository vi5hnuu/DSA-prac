# DSA--GeeksForGeeks
 DSA-Self Paced Course Solutions in C++


### About this course:  
This is a course designed by geeksforgeeks for Data Structures and Algorithms which covers below contents:  
+ Introduction
+ [Mathematics](Mathematics)
+ [Bit Magic](BitMagic)
+ [Recursion](Recursion)
+ [Arrays](Arrays)
+ Searching
+ Sorting
+ Matrix
+ Hashing
+ [Strings](Strings)
+ LinkedList
+ Stack
+ Queue
+ [Tree](Tree)
+ [Binary Search Tree](BST)
+ Heap
+ Graph
+ Greedy 
+ Dynamic Programming
+ Backtracking
+ Graph (Advanced)
+ Tree
+ Segment-Tree
+ Disjoint set

All the problems solutions are provided here , click on desired option to jump on that folder directly 


 
