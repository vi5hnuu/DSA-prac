double termOfGP(int A,double B,int N)
{
   double r = B/A; 
    return A * pow(r, N-1);
}
