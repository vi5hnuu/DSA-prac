**rest code is already available in IDE**


//You need to complete this function
double cToF(int C)
{
    //Your code here
    return (1.8*C+32);
}
