#define d 256 

bool search(string pat, string txt, int q)
{
if(txt.find(pat)==string::npos)
return false;

return true;
}
