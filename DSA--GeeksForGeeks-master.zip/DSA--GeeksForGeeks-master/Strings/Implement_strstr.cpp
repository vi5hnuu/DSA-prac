int strstr(string s, string x)
{
int f=-1;
f=s.find(x);
return f;

}
